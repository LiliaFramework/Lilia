------------------------------------------------------------------------------------------------------------------------
lia.command.add(
    "admincharbanksearch",
    {
        onRun = function(client, arguments) end
    }
)

------------------------------------------------------------------------------------------------------------------------
lia.command.add(
    "charbanksearch",
    {
        onRun = function(client, arguments) end
    }
)

------------------------------------------------------------------------------------------------------------------------
lia.command.add(
    "allowcarentry",
    {
        onRun = function(client, arguments) end
    }
)

------------------------------------------------------------------------------------------------------------------------
lia.command.add(
    "gagplayer",
    {
        onRun = function(client, arguments) end
    }
)

------------------------------------------------------------------------------------------------------------------------
lia.command.add(
    "blindplayer",
    {
        onRun = function(client, arguments) end
    }
)

------------------------------------------------------------------------------------------------------------------------
lia.command.add(
    "tieplayer",
    {
        onRun = function(client, arguments) end
    }
)

------------------------------------------------------------------------------------------------------------------------
lia.command.add(
    "dragplayer",
    {
        onRun = function(client, arguments) end
    }
)

------------------------------------------------------------------------------------------------------------------------
lia.command.add(
    "setrestricted",
    {
        onRun = function(client, arguments) end
    }
)

------------------------------------------------------------------------------------------------------------------------
lia.command.add(
    "setblinded",
    {
        onRun = function(client, arguments) end
    }
)

------------------------------------------------------------------------------------------------------------------------
lia.command.add(
    "setallowcar",
    {
        onRun = function(client, arguments) end
    }
)

------------------------------------------------------------------------------------------------------------------------
lia.command.add(
    "setgagged",
    {
        onRun = function(client, arguments) end
    }
)

----------------------------------------------------------------------------------------------
lia.command.add(
    "charsearch",
    {
        onRun = function(client, arguments) end
    }
)

----------------------------------------------------------------------------------------------
lia.command.add(
    "admincharsearch",
    {
        syntax = "<string target>",
        onRun = function(client, arguments) end
    }
)