--------------------------------------------------------------------------------------------------------
lia.command.add(
	"toggleraise",
	{
		adminOnly = false,
		privilege = "Basic User Permissions",
		onRun = function(client, arguments) end
	}
)
--------------------------------------------------------------------------------------------------------