--------------------------------------------------------------------------------------------------------
MODULE.name = "Raise Weapons"
MODULE.author = "STEAM_0:1:176123778/Cheesenut"
MODULE.desc = "Allows players to raise/lower weapons by holding R (reload)."
--------------------------------------------------------------------------------------------------------
lia.config.WepAlwaysRaised = true
--------------------------------------------------------------------------------------------------------
lia.config.PermaRaisedWeapons = {
    ["weapon_physgun"] = true,
    ["gmod_tool"] = true,
    ["lia_poshelper"] = true,
}
--------------------------------------------------------------------------------------------------------