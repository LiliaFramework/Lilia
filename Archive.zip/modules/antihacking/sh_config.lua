--------------------------------------------------------------------------------------------------------
lia.config.KnownExploits = {
    ["npctool_relman_up"] = true, 
    ["npctool_spawner_clearundo"] = true, 
    ["sv_npctool_spawner_ppoint"] = true, 
    ["wire_expression2_request_file"] = true, 
    ["wire_adv_upload"] = true, 
    ["wire_expression2_request_list"] = true, 
    ["wire_adv_unwire"] = true, 
    ["wire_expression2_client_request_set_extension_status"] = true
}
--------------------------------------------------------------------------------------------------------
lia.config.HackCommands = {"loki_menu", "gear_printents", "gw_toggle", "gw_pos", "gearmenu", "gb_reload", "gb_toggle", "+gb", "-gb", "gb_menu", "gear2_menu", "ahack_menu", "sasha_menu", "showents", "showhxmenu", "SmegHack_Menu", "sCheat_menu", "lowkey_menu"}
--------------------------------------------------------------------------------------------------------
lia.config.LokiNetMessages = {"pplay_deleterow", "pplay_addrow", "pplay_sendtable", "WriteQuery", "VJSay", "SendMoney", "BailOut", "customprinter_get", "textstickers_entdata", "NC_GetNameChange", "ATS_WARP_REMOVE_CLIENT", "ATS_WARP_FROM_CLIENT", "ATS_WARP_VIEWOWNER", "CFRemoveGame", "CFJoinGame", "CFEndGame", "Keypad", "CreateCase", "rprotect_terminal_settings", "StackGhost", "RevivePlayer", "ARMORY_RetrieveWeapon", "TransferReport", "SimplicityAC_aysent", "pac_to_contraption", "SyncPrinterButtons76561198056171650", "sendtable", "steamid2"}
--------------------------------------------------------------------------------------------------------