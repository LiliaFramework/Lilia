--------------------------------------------------------------------------------------------------------
lia.command.add(
    "pktoggle",
    {
        privilege = "Characters - Toogle Permakill",
        syntax = "<string target>",
        onRun = function(client, arguments) end
    }
)
--------------------------------------------------------------------------------------------------------