--------------------------------------------------------------------------------------------------------
lia.command.add(
    "whitelistadd",
    {
        privilege = "Management - Whitelist Change",
        superAdminOnly = true,
        onRun = function(client, arguments) end
    }
)
--------------------------------------------------------------------------------------------------------
lia.command.add(
    "whitelistremove",
    {
        privilege = "Management - Whitelist Change",
        superAdminOnly = true,
        onRun = function(client, arguments) end
    }
)
--------------------------------------------------------------------------------------------------------
lia.command.add(
    "whitelistclear",
    {
        privilege = "Management - Whitelist Change",
        superAdminOnly = true,
        onRun = function(client, arguments) end
    }
)
--------------------------------------------------------------------------------------------------------
lia.command.add(
    "whitelistaddall",
    {
        privilege = "Management - Whitelist Change",
        superAdminOnly = true,
        onRun = function(client, arguments) end
    }
)
--------------------------------------------------------------------------------------------------------