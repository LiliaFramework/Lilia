--------------------------------------------------------------------------------------------------------
lia.command.add(
    "rollstrength",
    {
        adminOnly = false,
        privilege = "Basic User Permissions",
        syntax = "[number maximum]",
        onRun = function(client, arguments) end
    }
)
--------------------------------------------------------------------------------------------------------
lia.command.add(
    "rollendurance",
    {
        adminOnly = false,
        privilege = "Basic User Permissions",
        syntax = "[number maximum]",
        onRun = function(client, arguments) end
    }
)
--------------------------------------------------------------------------------------------------------