--------------------------------------------------------------------------------------------------------
lia.config.DefaultStamina = 100
lia.config.RollMultiplier = 1
lia.config.StrengthMultiplier = 2.0
lia.config.PunchStrengthMultiplier = 0.7
lia.config.PunchStamina = 10
lia.config.StaminaSlowdown = true
lia.config.StaminaBlur = false
lia.config.MeleeDamageBonus = false
lia.config.MeleeWeapons = {"weapon_crowbar", "weapon_knife",}
--------------------------------------------------------------------------------------------------------