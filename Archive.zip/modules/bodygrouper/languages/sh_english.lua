--------------------------------------------------------------------------------------------------------
NAME = "english"
--------------------------------------------------------------------------------------------------------
LANGUAGE = {
    bodygroupChanged = "You have changed %s bodygroups and/or skin.",
    bodygroupChangedBy = "%s has changed your bodygroups and/or skin.",
    invalidSkin = "Invalid skin!",
    invalidBodygroup = "Invalid bodygroup!",
}
--------------------------------------------------------------------------------------------------------