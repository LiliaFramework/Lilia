--------------------------------------------------------------------------------------------------------
local MODULE = MODULE
--------------------------------------------------------------------------------------------------------
MODULE.name = "Bodygrouper"
MODULE.author = "DoopieWop [Base Code] || Leonheart [Lilia Port]"
MODULE.desc = "Adds a bodygroup menu and bodygroup closet, akin to BodygroupR on GModStore"
--------------------------------------------------------------------------------------------------------
lia.util.include("cl_module.lua")
lia.util.include("sv_module.lua")
lia.util.include("sh_config.lua")
--------------------------------------------------------------------------------------------------------