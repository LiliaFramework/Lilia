--------------------------------------------------------------------------------------------------------
lia.config.BodygrouperOpenSound = "doors/door_metal_thin_open1.wav"
lia.config.BodygrouperCloseSound = "doors/door_metal_thin_close2.wav"
lia.config.BodygrouperModel = "models/props_wasteland/controlroom_storagecloset001a.mdl"
lia.config.BodygrouperAdminOnly = true
--------------------------------------------------------------------------------------------------------