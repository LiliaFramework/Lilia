--------------------------------------------------------------------------------------------------------
lia.command.add(
	"storagelock",
	{
		privilege = "Management - Lock Storage",
		adminOnly = true,
		syntax = "[string password]",
		onRun = function(client, arguments) end
	}
)
--------------------------------------------------------------------------------------------------------