--------------------------------------------------------------------------------------------------------
lia.command.add(
    "banooc",
    {
        privilege = "Management - Ban OOC",
        syntax = "<string target>",
        onRun = function(client, arguments) end
    }
)
--------------------------------------------------------------------------------------------------------
lia.command.add(
    "unbanooc",
    {
        privilege = "Management - Unban OOC",
        syntax = "<string target>",
        onRun = function(client, arguments) end
    }
)
--------------------------------------------------------------------------------------------------------
lia.command.add(
    "blockooc",
    {
        privilege = "Management - Block OOC",
        syntax = "<string target>",
        onRun = function(client, arguments) end
    }
)
--------------------------------------------------------------------------------------------------------