--------------------------------------------------------------------------------------------------------------------------
lia.command.add(
    "rollstrength",
    {
        adminOnly = false,
        privilege = "Default User Commands",
        syntax = "[number maximum]",
        onRun = function(client, arguments) end
    }
)

--------------------------------------------------------------------------------------------------------------------------
lia.command.add(
    "rollendurance",
    {
        adminOnly = false,
        privilege = "Default User Commands",
        syntax = "[number maximum]",
        onRun = function(client, arguments) end
    }
)
--------------------------------------------------------------------------------------------------------------------------