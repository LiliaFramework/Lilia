--------------------------------------------------------------------------------------------------------------------------
CAMI.RegisterPrivilege(
    {
        Name = "Lilia - Staff Permissions - Development HUD",
        MinAccess = "superadmin",
        Description = "Allows access to Development HUD.",
    }
)

--------------------------------------------------------------------------------------------------------------------------
CAMI.RegisterPrivilege(
    {
        Name = "Lilia - Staff Permissions - Staff HUD",
        MinAccess = "superadmin",
        Description = "Allows access to Staff HUD.",
    }
)
--------------------------------------------------------------------------------------------------------------------------