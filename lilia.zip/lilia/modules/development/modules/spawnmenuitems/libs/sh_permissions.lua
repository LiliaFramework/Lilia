--------------------------------------------------------------------------------------------------------------------------
CAMI.RegisterPrivilege(
    {
        Name = "Lilia - Staff Permissions - Can Spawn Menu Items",
        MinAccess = "superadmin",
        Description = "Allows access to Spawning Menu Items.",
    }
)
--------------------------------------------------------------------------------------------------------------------------