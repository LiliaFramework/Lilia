--------------------------------------------------------------------------------------------------------------------------
lia.EasyRegister = lia.EasyRegister or {}
--------------------------------------------------------------------------------------------------------------------------
lia.EasyRegister.primary = {
    ["weapon_smg1"] = {
        ["name"] = "Sub Machine Gun",
        ["desc"] = "A Sub Machine Gun",
        ["model"] = "models/weapons/w_smg1.mdl",
        ["class"] = "weapon_smg1",
        ["width"] = 2,
        ["height"] = 2,
        ["price"] = 0,
    },
    ["weapon_ar2"] = {
        ["name"] = "Pulse-Rifle",
        ["desc"] = "A Pulse-Rifle",
        ["model"] = "models/weapons/w_IRifle.mdl",
        ["class"] = "weapon_ar2",
        ["width"] = 2,
        ["height"] = 2,
        ["price"] = 0,
    },
}
--------------------------------------------------------------------------------------------------------------------------