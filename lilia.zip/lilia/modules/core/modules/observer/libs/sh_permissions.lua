--------------------------------------------------------------------------------------------------------------------------
CAMI.RegisterPrivilege(
    {
        Name = "Lilia - Staff Permissions - No Clip",
        MinAccess = "superadmin",
        Description = "Allows access to No Clip.",
    }
)

--------------------------------------------------------------------------------------------------------------------------
CAMI.RegisterPrivilege(
    {
        Name = "Lilia - Staff Permissions - No Clip ESP",
        MinAccess = "superadmin",
        Description = "Allows access to No Clip ESP.",
    }
)
--------------------------------------------------------------------------------------------------------------------------