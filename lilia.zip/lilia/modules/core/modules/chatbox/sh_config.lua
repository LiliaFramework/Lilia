--------------------------------------------------------------------------------------------------------------------------
lia.config.CustomChatSound = ""
lia.config.ChatColor = Color(255, 239, 150)
lia.config.ChatRange = 280
lia.config.ChatShowTime = false
lia.config.OOCLimit = 150
lia.config.ChatListenColor = Color(168, 240, 170)
lia.config.OOCDelay = 10
lia.config.OOCDelayAdmin = false
lia.config.LOOCDelayAdmin = false
lia.config.LOOCDelay = 6
lia.config.ChatSizeDiff = false
lia.config.MaxChatLength = 256
--------------------------------------------------------------------------------------------------------------------------